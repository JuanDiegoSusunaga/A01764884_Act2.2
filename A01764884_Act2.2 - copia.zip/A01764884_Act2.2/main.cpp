#include <iostream>
#include <vector>
#include <algorithm>

// Juan Diego Susunaga - A01764884

std::vector<int> suffixArrayNaive(std::string S)  // // suffix Array

{
    int n = S.length();
    std::vector<std::string> sa;
    std::vector<int> A(n);
    S = S + "$";
    for (int i = 0; i < n; i++) {
        sa.push_back(S.substr(i));
    }
    std::sort(sa.begin(), sa.end());
    for (int i = 0; i < n; i++) {
        A[i] = n - sa[i].size() + 1;
    }
    return A;
}

int main() {
    std::string s;
    std::getline(std::cin, s);
    std::vector<int> suffixArray = suffixArrayNaive(s);

    std::vector<std::pair<std::string, int>> substrings;
    for (int i = 0; i < s.size(); i++) {
        substrings.emplace_back(s.substr(i), i + 1);
    }

    std::sort(substrings.begin(), substrings.end());

    for (const auto& p : substrings) {
        std::cout << p.second << std::endl;
    }

    return 0;
}
